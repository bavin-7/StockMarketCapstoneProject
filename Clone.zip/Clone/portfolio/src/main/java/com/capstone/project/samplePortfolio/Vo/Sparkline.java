package com.capstone.project.samplePortfolio.Vo;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class Sparkline {

        @JsonProperty
        private List<Double> price;

}
