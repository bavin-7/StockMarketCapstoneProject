package com.capstone.project.samplePortfolio.exception;

public class PortfolioNotFoundException extends Exception{
    public PortfolioNotFoundException(String msg){
        super(msg);
    }
}
