package com.capstone.project.samplePortfolio.exception;

public class StockNotFoundException extends Exception{
    public StockNotFoundException(String msg){
        super(msg);
    }
}
