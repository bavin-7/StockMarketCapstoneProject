package com.capstone.project.samplePortfolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SamplePortfolioApplicationTestsController {

	@Test
	void contextLoads() {
	}

}
